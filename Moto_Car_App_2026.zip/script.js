function playGame() {
    const car = document.querySelector(".car");
    const status = document.getElementById("status");
    const button = document.getElementById("playButton");

    car.classList.add("move-car");
    status.textContent = "🏁 The race has started! Drive fast! 🏎️";
    button.textContent = "🏎️ PLAYING...";
    button.disabled = true;
}
